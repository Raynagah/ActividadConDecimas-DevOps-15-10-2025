import React from "react";
export default function Titulo({ text }) {
  return <h2 className="text-2xl font-bold mb-4">{text}</h2>;
}
